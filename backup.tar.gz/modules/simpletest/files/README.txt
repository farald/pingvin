$Id: README.txt,v 1.2 2010/04/28 20:25:21 dries Exp $

These files are use in some tests that upload files or other operations were
a file is useful. These files are copied to the files directory as specified
in the site settings. Other tests files are generated in order to save space.
