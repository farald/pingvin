
Goals
==============
- Create a unified Drupal API for web services to be exposed in a variety of 
  different server formats.  
- Provide a service browser to be able to test methods.
- Allow distribution of API keys for developer access.

Documentation
==============
http://drupal.org/node/109782